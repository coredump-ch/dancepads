# Dancepad

## Description

This is a [LibrePCB](http://librepcb.org) project!
Just edit this file to add a description about it.

## License

See [LICENSE.txt](LICENSE.txt).
